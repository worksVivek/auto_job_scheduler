package com.example.auto_job_runner.enums;

public enum Status {
    CREATED,
    RUNNING,
    FAILED,
    SUCCESS

    }
