package com.example.auto_job_runner.enums;

public enum JobType {
    API,
    SCRIPT
}
